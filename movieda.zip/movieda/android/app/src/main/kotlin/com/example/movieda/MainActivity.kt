package com.example.movieda

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
